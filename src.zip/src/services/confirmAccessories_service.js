import { InventorymanagementRepository } from "../databases/repository/invetory-controller-repository.js";
import { ShopmanagementRepository } from "../databases/repository/shop-repository.js";
import { APIError, STATUS_CODE } from "../Utils/app-error.js";

class ConfirmAccessorymanagementService {
  constructor(repository = {}) {
    this.repository = {
      inventory: repository.inventory || new InventorymanagementRepository(),
      shop: repository.shop || new ShopmanagementRepository(),
    };
  }
  async confirmDistribution(confirmdeleliverydetails) {
    try {
      const { shopname, userId, productId, quantity, transferId } =
        confirmdeleliverydetails;

      const [
        stockId,
        transferproductId,
        parsedQuantity,
        parsedTransferId,
        parsedUserId,
      ] = [
        parseInt(productId, 10),
        parseInt(transferId, 10),
        parseInt(quantity, 10),
        parseInt(transferId, 10),
        parseInt(userId, 10),
      ];

      if (
        [
          stockId,
          transferproductId,
          parsedQuantity,
          parsedTransferId,
          parsedUserId,
        ].some(isNaN)
      ) {
        throw new APIError(
          "bad request",
          STATUS_CODE.BAD_REQUEST,
          "Invalid values provided"
        );
      }
      let [accessoryProduct, shopFound] = await Promise.all([
        this.repository.inventory.findProductById(stockId),
        this.repository.shop.findShop({ name: shopname }),
      ]);

      this.validationProcess(accessoryProduct, shopFound, parsedUserId);
      this.findTheAccessory(shopFound, parsedTransferId, parsedQuantity);
      const shopId = parseInt(shopFound.id);
      await this.transferProcess(parsedTransferId, parsedUserId, shopId);
    } catch (err) {
      if (err instanceof APIError) {
        throw err;
      }
      throw new APIError(
        "Distribution service error",
        STATUS_CODE.INTERNAL_ERROR,
        "Internal server error"
      );
    }
  }

  validationProcess(accessoryProduct, shopFound, parsedUserId) {
    if (!accessoryProduct) {
      throw new APIError(
        "Product not found",
        STATUS_CODE.NOT_FOUND,
        "Product not found"
      );
    }
    if (["deleted", "suspended"].includes(accessoryProduct.stockStatus)) {
      throw new APIError(
        "Bad Request",
        STATUS_CODE.BAD_REQUEST,
        `this product is ${accessoryProduct.stockStatus}`
      );
    }
    if (!shopFound) {
      throw new APIError("not found", STATUS_CODE.NOT_FOUND, "SHOP NOT FOUND");
    }
    if (
      !shopFound.assignment.some((seller) => seller.actors.id === parsedUserId)
    ) {
      throw new APIError(
        "Unauthorized",
        STATUS_CODE.UNAUTHORIZED,
        "You are not authorized to confirm arrival"
      );
    }
  }

  findTheAccessory(shopFound, parsedTransferId, quantity) {
    const newAccessory = shopFound.accessoryItems.find((item) => {
      return item.accessoryID !== null && item.transferId === parsedTransferId;
    });
    if (!newAccessory) {
      throw new APIError(
        "not found",
        STATUS_CODE.NOT_FOUND,
        " NEW ACCESSORY  NOT FOUND"
      );
    }
    if (newAccessory.status === "confirmed") {
      throw new APIError(
        "not found",
        STATUS_CODE.NOT_FOUND,
        "ACCESSORY ALREADY CONFIRMED"
      );
    }
    if (newAccessory.quantity < quantity) {
      throw new APIError(
        "not found",
        STATUS_CODE.NOT_FOUND,
        "NOT ENOUGH QUANTITY"
      );
    }
    return newAccessory;
  }

  async transferProcess(parsedTransferId, parsedUserId, shopId) {
    const updates = {
      status: "confirmed",
      confirmedBy: parsedUserId,
      updatedAt: new Date(),
    };
    await Promise.all([
      this.repository.inventory.updateTransferHistory(
        parsedTransferId,
        updates
      ),
      this.repository.shop.updateConfirmationOfAccessory(
        shopId,
        parsedTransferId,
        parsedUserId
      ),
    ]);
  }
}

export { ConfirmAccessorymanagementService };
